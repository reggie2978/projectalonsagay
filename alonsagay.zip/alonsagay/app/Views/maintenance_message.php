<!DOCTYPE html>
<html>
<head>
    <title>System Maintenance</title>
</head>
<body style="text-align:center;padding:50px;font-family:Arial">
    <h1>🚧 System Under Maintenance</h1>
    <p>We are currently upgrading our system. Please check back later.</p>
</body>
</html>
